
public interface LevelComponent {
	
    public String draw();

}
