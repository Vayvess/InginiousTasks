
public class Floor implements LevelComponent {

    public Floor(){}

    public String draw(){
        return "-";
    }
}
