
public class Wall implements LevelComponent {

    public Wall(){}

    public String draw(){
        return "#";
    }
}
