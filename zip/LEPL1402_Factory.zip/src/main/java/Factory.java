
abstract class Factory {

    abstract LevelComponent getElement(char c);


}
