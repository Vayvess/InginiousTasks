
public class Door implements LevelComponent {

    public Door(){}

    public String draw(){
        return "D";
    }

}
